#### 1.5
- Ignore dynamic content
- Detect int-only parameters
- Include URL in json output
- Track each reflection separately
- Improved error handling

#### 1.4
- Added `JSON` support
- Fixed a major bug in detection logic
- `-o` option to save result to a file
- `--urls` option to scan list of URLs
- Ability to supply HTTP headers from CLI

#### 1.3
- improved logic
- detection by plain-text content matching
- `--include` switch to include persistent data
- fixed a bug that caused user supplied HTTP headers to have no effect

#### 1.2-beta
- Drastic performance improvement (x50 faster)

#### 1.1
Initial stable release
