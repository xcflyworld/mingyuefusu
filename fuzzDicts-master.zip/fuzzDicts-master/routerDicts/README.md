全向QL168010.0.0.2，用户名admin密码是qxcomm1680，管理员密码是qxcommsupport 

全向QL1880192.168.1.1，用户名root密码是root 

全向QL168810.0.0.2，用户名admin；密码为qxcomm1688 

TP-LINKTD-8800在IE输入192.168.1.1,用户名admin,密码为admin. 

合勤zyxel642telnet192.168.1.1密码1234 

EcomED-802EG在IE输入192.168.1.1用户名和密码都为root 

神州数码6010RA在IE输入192.168.1.1　用户名ADSL密码为ADSL1234 

华为SmartAXMT800初始IP是192.168.1.1用户名和密码都为admin 

伊泰克http://192.168.1.1用户名：supervisor密码：12345 

华硕http://192.168.1.1用户名：adsl密码：adsl1234 

阿尔卡特http://192.168.1.1一般没有密码 

同维DSL699Ehttp://192.168.1.1用户名：ROOT密码为：ROOT 

大亚DB102http://192.168.1.1用户名：admin密码：dare 

WST的RT1080http://192.168.0.1username:rootpassword:root 

WST的ART18CXhttp://10.0.0.2username:adminpassword:conexant  

全向qxcomm1688http://192.168.1.1高端设置密码是：qxcommsuport 

全向qxcomm1680http://192.168.1.1用户：qxcomm1680密码:qxcomm1680 

实达 username:user password:password

实达ADSL2110-EHaddress:192.168.10.1user:adminpwd:starnetadsl 

V3.2　rootroot 

V5.4　rootgrouter 

泛德用户：admin密码：conexant 

东信Ea700http://192.168.1.1用户名：空密码：password 

broadmax的hsa300ahttp://192.168.0.1username:broadmax 

password:broadmax 

长虹ch-500Ehttp://192.168.1.1username:rootpassword:root 

重庆普天CPADSL03http://192.168.1.1username:rootpassword:root 

台湾突破EA110RS232:38400[url]http://192.168.7.1username:SLpsw:SL 

etek-td的ADSL_T07L006.0http://192.168.1.1UserName:supervisor 

Password:12345 

GVC的DSL-802E/R3Ahttp://10.0.0.2username:adminpassword:epicrouter

username:userpassword:password 

科迈易通km300A-1http://192.168.1.1username:password:password 

科迈易通km300A-Ghttp://192.168.1.1username:rootpassword:root 

科迈易通km300A-Ausername:rootoradminpassword:123456 

sunrise的SR-DSL-AEhttp://192.168.1.1username:adminpassword:0000 

sunrise的DSL-802E_R3Ahttp://10.0.0.2username:admin 

password:epicrouter 

username:userpassword:password 

UTStar的ut-300Rhttp://192.168.1.1 username:admin 

password:utstar 

湖北邮通IP:10.0.0.2 Username:admin Password:epicrouter 

亨威NSM500网速通IP:192.168.1.1 Username:root Password:root 

艾玛701g192.168.101.1192.168.0.1用户名：admin密码：admin 

用户名：SZIM 密码：SZIM 

艾玛701H192.168.1.110.0.0.2用户名：admin密码：epicrouter

实达2110EHROUTER 192.168.10.1 用户名：user密码：password 

用户名：root密码：grouter 

神州数码/华硕：用户名：adsl密码：adsl1234 

全向：用户名：root密码：root 

普天：用户名：admin密码：dare 

e-tek用户名:admin密码:12345 

zyxel用户名:anonymous密码:1234 

北电用户名:anonymous密码:12345

大恒用户名：admin密码：admin 

大唐用户名：admin密码：1234 

斯威特用户名：root密码：root 

用户名：user密码：user 

中兴用户名：adsl密码：adsl831
